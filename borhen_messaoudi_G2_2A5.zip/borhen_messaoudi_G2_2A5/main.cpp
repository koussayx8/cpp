#include <iostream>

#include<string>
#include"Projet.h"
#include"ProjetFinance.h"
#include"objectifDD.h"
#include"Pole.h"
using namespace std;

int main()
{
    // Création d'un objet Pole
    Pole monPole("Mon Pole");

    // Ajout de projets normaux
    Projet projet1(1, "Projet 1", 5000, 0);
    Projet projet2(2, "Projet 2", 3000, 0);
    Projet projet3(3, "Projet 3", 8000, 0);

    // Ajout de projets financés
    ProjetFinance projetFinance1(4, "Projet Finance 1", 6000, 0, 2000);
    ProjetFinance projetFinance2(5, "Projet Finance 2", 4000, 0, 1500);
    ProjetFinance projetFinance3(6, "Projet Finance 3", 7000, 0, 3000);

    // Ajout des projets au pôle
    monPole.ajouterP(projet1);
    monPole.ajouterP(projet2);
    monPole.ajouterP(projet3);
    monPole.ajouterP(projetFinance1);
    monPole.ajouterP(projetFinance2);
    monPole.ajouterP(projetFinance3);

    // Calcul et mise à jour de l'indiceDD dans tous les projets du pôle
    monPole.calculerEtMettreAJourIndiceDD();

    // Affichage des projets ayant un budget alloué par objectif inférieur à 1000
    monPole.afficherProjetsBudgetInferieur(monPole, 1000);

    // Enregistrement des projets financés dans un fichier texte
    monPole.enregistrerProjetsFinances("projets_finances.txt");

    return 0;


}
