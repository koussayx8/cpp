#include "objectifDD.h"

objectifDD::objectifDD()
{
    //ctor
}

objectifDD::~objectifDD()
{
    //dtor
}
objectifDD::objectifDD(int id ,int libelle)
{
   this->id=id;
   this->libelle=libelle;
}
