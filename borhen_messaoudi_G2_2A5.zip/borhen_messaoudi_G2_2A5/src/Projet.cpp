#include "Projet.h"

Projet::Projet()
{
    indiceDD = 0;
}

Projet::~Projet()
{
    //dtor
}

Projet::Projet(int id, string nom, int budget, int indiceDD)
{
    this->id = id;
    this->nom = nom;
    this->budget = budget;
    this->indiceDD = indiceDD;
}

objectifDD* Projet::getobjectif(int id)
{
    vector<objectifDD>::iterator i;
    for (i = tabO.begin(); i != tabO.end(); i++)
    {
        if (id == (*i).getid())
        {
            return &(*i);
        }
    }
    return nullptr;
}

void Projet::ajouterobjectif(const objectifDD& o)
{
    if (getobjectif(o.getid()) == nullptr)
    {
        tabO.push_back(o);
    }
}


bool Projet::operator<(int valeur) const
{
    for (objectifDD objectif : tabO)
    {
        if (objectif.getbudgetAutoFinancement() >= valeur)
        {
            return false;
        }
    }
    return true;
}


