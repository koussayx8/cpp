#include "Pole.h"

#include<fstream>
#include<typeinfo>
Pole::Pole()
{
    //ctor
}Pole::Pole(string)
{
       this->nom=nom;
}


/////////////////////////////OERATEUR EGALE

Pole& Pole::operator=(const Pole &p)
{
    if(&p!=this)
    {
        vector <Projet*>::iterator i ;
        for(i=tabP.begin(); i!=tabP.end(); i++)
        {
            delete (*i);
        }
        tabP.clear();

        Projet*f;
        for(vector<Projet*>::const_iterator i=p.tabP.begin(); i != p.tabP.end(); i++)
        {

            if(typeid(**i)==typeid(Projet))
            {
                f=new Projet(**i);
            }
            else if(typeid(**i)==typeid(ProjetFinance))
            {
                f=new ProjetFinance(static_cast<const ProjetFinance&>(**i));
            }

            tabP.push_back(f);
        }
    }
    return* this;
}
///////CONSTRUCTEUR DE COPIE
Pole::Pole(const Pole&p)
{
    Projet*f;
    for(vector<Projet*>::const_iterator i=p.tabP.begin(); i != p.tabP.end(); i++)
    {
        if(typeid(**i)==typeid(Projet))
        {
            f=new Projet(**i);
        }
        else if(typeid(**i)==typeid(ProjetFinance))
        {
            f=new ProjetFinance(static_cast<const ProjetFinance&>(**i));
        }

        tabP.push_back(f);


}

}
////////////DESTRUCTEUR
Pole::~Pole()
{

    vector <Projet*>::iterator i ;

    for(i=tabP.begin(); i!=tabP.end(); i++)
    {
        delete (*i);
    }

}


Projet * Pole::getprojet(int id)
{
    vector<Projet*>::iterator i;
    for(i=tabP.begin();i!=tabP.end();i++)
    {
        if(id==(*i)->getid()){return *i;}
    }
    return NULL;
}


void Pole::ajouterP(const Projet &p)
{
        if(getprojet(p.getid())==NULL){
            Projet *pr=new Projet(p);
            tabP.push_back(pr);

}
}

void Pole::ajouterP(const ProjetFinance &p)
{
        if(getprojet(p.getid())==NULL){
            Projet *pr=new ProjetFinance(p);
            tabP.push_back(pr);

}
}


void Pole::enregistrer(int indiceDD)
{
    ofstream save("save.txt",ios::app);
    vector<Projet*>::iterator i;
    for(i=tabP.begin();i!=tabP.end();i++)
    {
        if(indiceDD==(*i)->getindiceDD())
        {
            save<<(*i)->getid();
            save<<(*i)->getindiceDD();
            }
    }
}

void Pole::calculerEtMettreAJourIndiceDD()
{
    for (Projet* projet : tabP)
    {
        int budgetAutoFinancement = 0;
        int montantFinancement = 0;
        int nombreObjectifDD = 0;

        for (objectifDD objectif : projet->gettabO())
        {
            budgetAutoFinancement += objectif.getbudgetAutoFinancement();
            nombreObjectifDD++;
        }

        // Calculer l'indiceDD en fonction du type de projet
        if (ProjetFinance* projetFinance = dynamic_cast<ProjetFinance*>(projet))
        {
            montantFinancement = projetFinance->getmontantf();
            projet->setindiceDD((budgetAutoFinancement + montantFinancement) / nombreObjectifDD);
        }
        else
        {
            projet->setindiceDD(budgetAutoFinancement / nombreObjectifDD);
        }
    }
}


void Pole::afficherProjetsBudgetInferieur(const Pole& pole, int valeur)
{
    for (Projet* projet : pole.tabP)
    {
        if (*projet < valeur)
        {
            // Afficher le projet ou effectuer l'action souhaitée
            // Exemple : cout << projet->getid() << endl;
        }
    }
}

