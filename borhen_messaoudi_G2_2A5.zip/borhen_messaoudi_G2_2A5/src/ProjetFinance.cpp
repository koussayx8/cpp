#include "ProjetFinance.h"

ProjetFinance::ProjetFinance()
{
    //ctor
}

ProjetFinance::~ProjetFinance()
{
    //dtor
}


ProjetFinance::ProjetFinance(int id,string nom,int budget,int indiceDD,float montantf):Projet(id, nom, budget, indiceDD)
{
    this->montantf=montantf;

}
