#ifndef POLE_H
#define POLE_H

#include<string>
#include<vector>
#include <fstream>
#include"Projet.h"
#include"ProjetFinance.h"

using namespace std;
class Pole
{
    public:
        Pole();
        Pole(string);
        Pole(const Pole&);
        Pole& operator=(const Pole &);
        virtual ~Pole();
        Projet *getprojet(int);
        void ajouterP(const Projet &);
        void ajouterP(const ProjetFinance &);
        void enregistrer(int);
        void calculerEtMettreAJourIndiceDD();
        void afficherProjetsBudgetInferieur(const Pole& pole, int valeur);

    protected:

    private:
        string nom;
        vector<Projet*>tabP;
};

#endif // POLE_H
