#ifndef PROJET_H
#define PROJET_H

#include<string>
#include<vector>
#include"objectifDD.h"
using namespace std;

class Projet
{
    public:
        Projet();
        Projet(int,string,int,int);
        virtual ~Projet();
        int getid()const{return id;}
        int getindiceDD()const{return indiceDD;}
        objectifDD *getobjectif(int);
        bool operator<(int valeur) const;


        void ajouterobjectif(const objectifDD&);

    protected:

    private:
        int id ;
        string nom;
        int budget ;
        int indiceDD ;
        vector<objectifDD>tabO;
};

#endif // PROJET_H
