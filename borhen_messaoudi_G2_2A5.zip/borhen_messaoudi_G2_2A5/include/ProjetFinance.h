#ifndef PROJETFINANCE_H
#define PROJETFINANCE_H

#include"Projet.h"

class ProjetFinance : public Projet
{
    public:
        ProjetFinance();
        ProjetFinance(int,string,int,int,float);
        virtual ~ProjetFinance();

    protected:

    private:
        float montantf ;
};

#endif // PROJETFINANCE_H
