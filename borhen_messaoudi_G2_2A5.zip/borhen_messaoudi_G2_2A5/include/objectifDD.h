#ifndef OBJECTIFDD_H
#define OBJECTIFDD_H


class objectifDD
{
    public:
        objectifDD();
        objectifDD(int,int);
        virtual ~objectifDD();
        int getid()const{return id;}
    protected:

    private:
        int id;
        int libelle;
};

#endif // OBJECTIFDD_H
